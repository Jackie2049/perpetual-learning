Ray API Design Tutorial
=======================================

Last updated: 10/30/2024.

We provide a tutorial for our Ray API design, including:

- Ray basic concepts
- Resource Pool and RayWorkerGroup
- Data Dispatch, Execution and Collection
- Initialize the RayWorkerGroup and execute the distributed computation in the given Resource Pool

See details in `tutorial.ipynb <https://github.com/verl-project/verl/blob/main/examples/tutorial/ray/tutorial.ipynb>`_.